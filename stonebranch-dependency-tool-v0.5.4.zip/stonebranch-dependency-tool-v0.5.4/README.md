# Stonebranch Dependency Tool v0.5.4

JSON-first terminal tool for creating and comparing dependency analysis packs:

- Stonebranch folder-based JSON export
- AutoSys JIL files
- Detailed mismatch analysis for migration cleanup

The recommended workflow is pack-based:

```text
Stonebranch repo  → Stonebranch analysis pack
JIL repo          → JIL analysis pack
Both packs        → Comparison analysis pack
```

## Start

Run:

```cmd
run_terminal_ui.cmd
```

or:

```cmd
python -m stonebranch_graph.cli tui
```

## Main menu

```text
1) Build Stonebranch analysis pack
2) Build JIL analysis pack
3) Compare analysis packs
4) Settings
5) Other tools
0) Exit
```

The main screen intentionally contains only the recommended workflow and navigation.

## Recommended workflow

### 1. Build Stonebranch analysis pack

Creates a self-contained folder with graph, indexes, Mermaid views, metrics, and reports.

```cmd
stonebranch-graph build-stonebranch-pack "C:\path\to\sb-orchestrator\envs\PROD" -o out\stonebranch-pack --env PROD --include-raw-values
```

### 2. Build JIL analysis pack

Creates a self-contained JIL-side analysis folder.

```cmd
stonebranch-graph build-jil-pack "C:\path\to\autosys-jil\PROD" -o out\jil-pack --env PROD --include-raw-values
```

### 3. Compare analysis packs

Compares two pack folders and writes a detailed discrepancy analysis.

```cmd
stonebranch-graph compare-packs --stonebranch-pack out\stonebranch-pack --jil-pack out\jil-pack -o out\compare-pack
```

## Source analysis pack contents

Both Stonebranch and JIL packs contain:

```text
README.md
pack-manifest.json
graph.json
metrics.json
metrics.csv
objects.csv
edges.csv
dependency-graph.mmd
dependency-graph.dot
report.md

indexes/
  node-index.json
  edge-index.json
  adjacency.json
  reverse-adjacency.json

graphs/
  full.mmd
  tasks-only.mmd
  dependencies-only.mmd
  triggers-to-tasks.mmd
  runtime.mmd
  calendars.mmd
  variables.mmd

reports/
  top-connected.md
  orphans.md
  relation-summary.csv
  object-summary.csv
```

`graph.json` is the source of truth. Indexes and graph views are generated from it.

## Comparison analysis pack contents

```text
compare-pack-manifest.json

compare/
  report.md
  comparison.json
  metrics.json
  metrics.csv
  edge-diff.csv
  missing-in-stonebranch.csv
  missing-in-jil.csv
  collisions.csv
  mapping-diagnostics.csv
  diff-index.json
  critical-diff.json
  remediation-plan.md
```

Start with:

```text
compare/report.md
compare/metrics.json
compare/critical-diff.json
compare/remediation-plan.md
```

`remediation-plan.md` is a checklist for closing migration gaps.

## Settings menu

```text
1) Show current settings
2) Source repository paths
3) Analysis pack folders
4) Environment and mapping
5) Parser and output options
6) Existing graph.json paths
7) Validate paths
8) Save settings
9) Load settings
R) Reset to defaults
0) Back
```

Settings are stored in:

```text
.stonebranch-tool-settings.json
```

## Other tools

Secondary actions are available under `Other tools`:

```text
1) Run direct compare: Stonebranch ↔ JIL
2) Compare existing graph.json files
3) Profile Stonebranch schema
4) Profile JIL schema
5) Show last output files
0) Back
```

## Runtime options

### Include raw values

Default is off. Command/script evidence is represented as a stable hash.

When enabled, graph edges may include normalized raw command/script values. Matching still uses stable identifiers/hashes where applicable.

### Deep scan

Enables broader string reference detection in Stonebranch JSON. This can find more references, but may produce false positives.

### Env-aware Stonebranch

Derives environment from folder layout like:

```text
envs/PROD/tasks/*.json
envs/DEV/tasks/*.json
```

## Key metrics

Comparison metrics include:

```text
migration_readiness_score
readiness_grade
node_match_rate_percent
edge_match_rate_percent
critical_dependency_loss_count
critical_dependency_extra_count
calendar_mismatch_count
agent_machine_mismatch_count
command_mismatch_count
condition_mismatch_count
synthetic_nodes_total
low_confidence_edges_total
```

Readiness grades:

```text
95–100  excellent
85–94   good
70–84   review_required
50–69   high_risk
0–49    unsafe
```

## Cleanup in v0.5.4

Removed obsolete legacy launchers/docs:

```text
run_compare_example.cmd
run_compare_your_repo.cmd
docs/HARDENING_v0.5.4.md
stonebranch_graph/parsers/base.py
```

Also cleaned unused imports and added pack workflow tests.


## v0.5.4 Terminal UX

Terminal UI now uses one-key menu selection:

```text
Press 1/2/3/4/5/0 directly.
No Enter required for menu actions.
```

Settings now include a built-in folder/file browser:

```text
1-9 open folder/file
C choose current folder
U go up
N/P next/previous page
H home
R roots/drives
M manual input
Q cancel
```

This reduces manual path typing for repository paths, pack folders, mapping JSON, and graph.json files.


## v0.5.4 Terminal UX

The old in-terminal directory browser was removed.

Menu actions still use one key:

```text
Press 1 / 2 / 3 / 4 / 5 / 0 directly.
No Enter required for menu actions.
```

Path settings now use native system pickers:

```text
B = open folder/file picker
C = keep current
M = manual input
E = empty, only for optional paths
```

For pack outputs, use:

```text
Settings → Analysis pack folders → Choose base output folder
```

The tool auto-fills:

```text
<base>\stonebranch-pack
<base>\jil-pack
<base>\compare-pack
```
