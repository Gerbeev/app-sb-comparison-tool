from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def test_tui_menu_mentions_one_key_and_system_pickers() -> None:
    root = Path(__file__).resolve().parents[1]
    result = subprocess.run(
        [
            sys.executable,
            "-c",
            "from stonebranch_graph.tui import print_menu_with_descriptions; print_menu_with_descriptions()",
        ],
        cwd=root,
        capture_output=True,
        text=True,
        timeout=60,
        env={**os.environ, "STONEBRANCH_FORCE_COLOR": "1"},
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "one key" in result.stdout
    assert "system pickers" in result.stdout
    assert "Build Stonebranch analysis pack" in result.stdout


def test_native_dialog_module_imports() -> None:
    from stonebranch_graph.native_dialogs import pick_directory, pick_file

    assert callable(pick_directory)
    assert callable(pick_file)


def test_tui_uses_simple_picker_methods() -> None:
    from stonebranch_graph.tui import TerminalUi

    ui = TerminalUi()
    assert callable(ui.pick_folder_setting)
    assert callable(ui.pick_file_setting)
    assert callable(ui.menu_choice)
