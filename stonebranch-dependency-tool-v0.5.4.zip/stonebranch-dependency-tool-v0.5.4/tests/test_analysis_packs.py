from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


def run_cli(root: Path, *args: str) -> None:
    result = subprocess.run(
        [sys.executable, "-m", "stonebranch_graph.cli", *args],
        cwd=root,
        capture_output=True,
        text=True,
        timeout=120,
    )
    assert result.returncode == 0, result.stdout + "\n" + result.stderr


def test_analysis_pack_workflow(tmp_path: Path) -> None:
    root = Path(__file__).resolve().parents[1]

    sb_pack = tmp_path / "stonebranch-pack"
    jil_pack = tmp_path / "jil-pack"
    compare_pack = tmp_path / "compare-pack"

    run_cli(
        root,
        "build-stonebranch-pack",
        str(root / "examples" / "stonebranch" / "PROD"),
        "-o",
        str(sb_pack),
        "--env",
        "PROD",
        "--include-raw-values",
    )
    run_cli(
        root,
        "build-jil-pack",
        str(root / "examples" / "jil" / "PROD"),
        "-o",
        str(jil_pack),
        "--env",
        "PROD",
        "--include-raw-values",
    )
    run_cli(
        root,
        "compare-packs",
        "--stonebranch-pack",
        str(sb_pack),
        "--jil-pack",
        str(jil_pack),
        "-o",
        str(compare_pack),
    )

    required = [
        sb_pack / "pack-manifest.json",
        sb_pack / "graph.json",
        sb_pack / "indexes" / "node-index.json",
        sb_pack / "indexes" / "adjacency.json",
        sb_pack / "graphs" / "dependencies-only.mmd",
        sb_pack / "reports" / "top-connected.md",
        jil_pack / "pack-manifest.json",
        jil_pack / "graph.json",
        jil_pack / "indexes" / "node-index.json",
        compare_pack / "compare-pack-manifest.json",
        compare_pack / "compare" / "comparison.json",
        compare_pack / "compare" / "metrics.json",
        compare_pack / "compare" / "critical-diff.json",
        compare_pack / "compare" / "diff-index.json",
        compare_pack / "compare" / "remediation-plan.md",
    ]

    for path in required:
        assert path.exists(), str(path)

    sb_manifest = json.loads((sb_pack / "pack-manifest.json").read_text(encoding="utf-8"))
    jil_manifest = json.loads((jil_pack / "pack-manifest.json").read_text(encoding="utf-8"))
    compare_manifest = json.loads((compare_pack / "compare-pack-manifest.json").read_text(encoding="utf-8"))

    assert sb_manifest["pack_type"] == "stonebranch-analysis-pack"
    assert jil_manifest["pack_type"] == "jil-analysis-pack"
    assert compare_manifest["pack_type"] == "comparison-analysis-pack"

    metrics = json.loads((compare_pack / "compare" / "metrics.json").read_text(encoding="utf-8"))
    assert "migration_readiness_score" in metrics
    assert "matched_nodes" in metrics
