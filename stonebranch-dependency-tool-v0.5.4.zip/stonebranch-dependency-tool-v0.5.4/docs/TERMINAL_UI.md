# Terminal UI

Start:

```cmd
run_terminal_ui.cmd
```

or:

```cmd
python -m stonebranch_graph.cli tui
```

## Main menu

```text
1) Build Stonebranch analysis pack
2) Build JIL analysis pack
3) Compare analysis packs
4) Settings
5) Other tools
0) Exit
```

The main menu is intentionally focused on the recommended pack workflow.

## Recommended workflow

### 1) Build Stonebranch analysis pack

Creates:

```text
out/stonebranch-pack/
  graph.json
  indexes/
  graphs/
  reports/
  metrics.json
  report.md
```

Use this first to parse and inspect the Stonebranch repository independently.

### 2) Build JIL analysis pack

Creates:

```text
out/jil-pack/
  graph.json
  indexes/
  graphs/
  reports/
  metrics.json
  report.md
```

Use this to parse and inspect JIL independently.

### 3) Compare analysis packs

Compares existing pack folders and writes:

```text
out/compare-pack/
  compare-pack-manifest.json
  compare/
    report.md
    comparison.json
    metrics.json
    edge-diff.csv
    critical-diff.json
    diff-index.json
    remediation-plan.md
```

Use this for the actual migration gap analysis.

## Settings

```text
1) Show current settings
2) Source repository paths
3) Analysis pack folders
4) Environment and mapping
5) Parser and output options
6) Existing graph.json paths
7) Validate paths
8) Save settings
9) Load settings
R) Reset to defaults
0) Back
```

### Source repository paths

Set:

```text
Stonebranch source folder
JIL source folder
```

### Analysis pack folders

Set:

```text
Stonebranch pack output folder
JIL pack output folder
Compare pack output folder
```

### Environment and mapping

Set:

```text
Environment name
Optional mapping.json path
```

### Parser and output options

Toggle:

```text
Include raw values
Deep scan
Env-aware Stonebranch
```

### Existing graph.json paths

Only needed for:

```text
Other tools → Compare existing graph.json files
```

## Other tools

```text
1) Run direct compare: Stonebranch ↔ JIL
2) Compare existing graph.json files
3) Profile Stonebranch schema
4) Profile JIL schema
5) Show last output files
0) Back
```

These are intentionally one level lower than the main workflow.

## Color scheme

- green: main compare flow and success
- cyan: pack/graph generation actions
- magenta: profile/schema actions
- yellow: settings/configuration
- gray: helper descriptions
- red: missing paths and errors

Disable colors:

```cmd
set NO_COLOR=1
run_terminal_ui.cmd
```

Force colors:

```cmd
set STONEBRANCH_FORCE_COLOR=1
run_terminal_ui.cmd
```


## v0.5.4 keyboard UX

Menu selection no longer requires Enter.

Use:

```text
1 / 2 / 3 / 4 / 5 / 0
```

directly.

## Folder/file browser

Path settings use a terminal browser.

Controls:

```text
1-9  open directory or select file
C    choose current folder
U    go up
N    next page
P    previous page
H    home
R    roots/drives
M    manual input
Q    cancel
```

Manual input remains available, but the default flow is browsing/choosing.


## v0.5.4 picker UX

The old terminal directory browser controls were removed.

Path settings use native system dialogs:

```text
B = open folder/file picker
C = keep current
M = manual input
E = empty, only for optional paths
```

For pack folders, choose one base output folder and let the tool auto-fill:

```text
<base>/stonebranch-pack
<base>/jil-pack
<base>/compare-pack
```
