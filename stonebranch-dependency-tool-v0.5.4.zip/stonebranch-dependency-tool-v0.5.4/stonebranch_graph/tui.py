from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import os
from pathlib import Path
import sys
import traceback
from typing import Any

from .compare import compare_graphs, export_comparison
from .config import AnalyzerConfig, MappingConfig
from .exporters import export_graph_bundle, load_graph_json
from .native_dialogs import pick_directory, pick_file
from .pack import compare_analysis_packs, create_analysis_pack
from .parsers.autosys_jil import AutosysJilParser
from .parsers.stonebranch_json import StonebranchJsonParser
from .schema_profiler import profile_jil, profile_stonebranch


SETTINGS_FILE = Path(".stonebranch-tool-settings.json")


PALETTE = {
    "bold": "1",
    "red": "31",
    "green": "32",
    "yellow": "33",
    "blue": "34",
    "magenta": "35",
    "cyan": "36",
    "gray": "90",
    "bright_red": "91",
    "bright_green": "92",
    "bright_yellow": "93",
    "bright_blue": "94",
    "bright_magenta": "95",
    "bright_cyan": "96",
    "bright_white": "97",
}


MAIN_MENU_ITEMS = [
    ("1", "Build Stonebranch analysis pack", "Create a full Stonebranch pack: graph.json, indexes, graph views, metrics, and source-side reports.", "PACK"),
    ("2", "Build JIL analysis pack", "Create a full JIL pack: graph.json, indexes, graph views, metrics, and source-side reports.", "PACK"),
    ("3", "Compare analysis packs", "Compare Stonebranch/JIL pack folders and produce detailed gaps, critical diffs, and remediation checklist.", "MAIN"),
    ("4", "Settings", "Open detailed configuration: paths, pack folders, mapping, environment, parser options, validation, save/load.", "SETUP"),
    ("5", "Other tools", "Direct compare, compare graph.json files, schema profiles, and last output file list.", "OTHER"),
    ("0", "Exit", "Save settings and close the terminal UI.", "EXIT"),
]


OTHER_MENU_ITEMS = [
    ("1", "Run direct compare: Stonebranch ↔ JIL", "Parse both repositories and compare immediately. Good for quick checks; packs are better for iterative analysis.", "GRAPH"),
    ("2", "Compare existing graph.json files", "Compare previously generated Stonebranch/JIL graph.json files without reparsing repositories.", "GRAPH"),
    ("3", "Profile Stonebranch schema", "Generate a safe structure profile of Stonebranch JSON keys and types without values.", "PROFILE"),
    ("4", "Profile JIL schema", "Generate a safe structure profile of JIL job blocks and attributes.", "PROFILE"),
    ("5", "Show last output files", "Print the most important files from the last run: manifests, reports, graph.json, metrics, diffs.", "SETUP"),
    ("0", "Back", "Return to the main menu.", "EXIT"),
]


SETTINGS_MENU_ITEMS = [
    ("1", "Show current settings", "Display all configured paths/options and mark existing/missing paths."),
    ("2", "Source repository paths", "Set Stonebranch repository folder and JIL folder using system folder picker."),
    ("3", "Analysis pack folders", "Set output folders for Stonebranch pack, JIL pack, and comparison pack."),
    ("4", "Environment and mapping", "Set environment name and optional mapping.json path."),
    ("5", "Parser and output options", "Toggle include raw values, deep scan, and env-aware Stonebranch layout."),
    ("6", "Existing graph.json paths", "Set Stonebranch/JIL graph.json paths for compare-existing-JSON mode."),
    ("7", "Validate paths", "Check source paths, graph.json paths, pack folders, and mapping file."),
    ("8", "Save settings", f"Write settings to {SETTINGS_FILE}."),
    ("9", "Load settings", f"Reload settings from {SETTINGS_FILE}."),
    ("R", "Reset to defaults", "Reset settings in memory. Use Save settings afterwards to persist."),
    ("0", "Back", "Return to the main menu."),
]


@dataclass
class TuiSettings:
    stonebranch_path: str = ""
    jil_path: str = ""
    stonebranch_graph_json: str = ""
    jil_graph_json: str = ""
    output_path: str = "out"
    stonebranch_pack_path: str = "out/stonebranch-pack"
    jil_pack_path: str = "out/jil-pack"
    compare_pack_path: str = "out/compare-pack"
    env: str = "PROD"
    mapping_path: str = ""
    include_raw_values: bool = False
    deep_scan: bool = False
    env_aware: bool = False


def supports_color() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("STONEBRANCH_FORCE_COLOR"):
        return True
    return sys.stdout.isatty()


def color_text(text: str, *styles: str) -> str:
    if not supports_color():
        return text
    codes = [PALETTE[style] for style in styles if style in PALETTE]
    return f"\033[{';'.join(codes)}m{text}\033[0m" if codes else text


def enable_windows_ansi() -> None:
    if os.name == "nt":
        os.system("")


def get_key() -> str:
    if not sys.stdin.isatty():
        return input().strip()[:1]

    if os.name == "nt":
        import msvcrt

        return msvcrt.getwch()

    import termios
    import tty

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        return sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def print_menu_with_descriptions() -> None:
    enable_windows_ansi()
    print()
    print(color_text("╔" + "═" * 86 + "╗", "bright_blue"))
    print(color_text("║ Stonebranch Dependency Tool · Terminal UI · Pack workflow".ljust(87) + "║", "bright_green", "bold"))
    print(color_text("╚" + "═" * 86 + "╝", "bright_blue"))
    print(color_text("Recommended flow: build Stonebranch pack → build JIL pack → compare packs.", "gray"))
    print(color_text("Menu actions use one key. Path settings use system pickers.", "bright_yellow"))
    print()
    for number, title, description, tag in MAIN_MENU_ITEMS:
        print_menu_item(number, title, description, tag)
    print(color_text("─" * 88, "bright_blue"))


def print_menu_item(number: str, title: str, description: str, tag: str) -> None:
    number_style, title_style, tag_style = style_for_tag(tag)
    print(f" {color_text(number.rjust(2), *number_style)}) {color_text(title, *title_style)}  {color_text(tag, *tag_style)}")
    print(f"     {color_text(description, 'gray')}")
    print()


def style_for_tag(tag: str) -> tuple[tuple[str, ...], tuple[str, ...], tuple[str, ...]]:
    if tag == "MAIN":
        return ("bright_green", "bold"), ("bright_white", "bold"), ("bright_green", "bold")
    if tag == "PACK":
        return ("bright_cyan", "bold"), ("bright_cyan",), ("cyan",)
    if tag == "PROFILE":
        return ("bright_magenta", "bold"), ("bright_magenta",), ("magenta",)
    if tag == "SETUP":
        return ("bright_yellow", "bold"), ("bright_yellow",), ("yellow",)
    if tag == "GRAPH":
        return ("bright_cyan", "bold"), ("bright_cyan",), ("cyan",)
    if tag == "OTHER":
        return ("bright_blue", "bold"), ("bright_blue",), ("blue",)
    return ("gray",), ("gray",), ("gray",)


class TerminalUi:
    def __init__(self) -> None:
        self.config = AnalyzerConfig.default()
        self.settings = self.load_settings()
        self.last_files: list[Path] = []
        self.last_summary: dict[str, Any] = {}

    def run(self) -> int:
        enable_windows_ansi()
        while True:
            self.clear()
            self.header()
            self.print_settings_compact()
            self.print_main_menu()
            choice = self.menu_choice("Select", {item[0] for item in MAIN_MENU_ITEMS})
            try:
                if choice == "1":
                    self.build_stonebranch_pack()
                elif choice == "2":
                    self.build_jil_pack()
                elif choice == "3":
                    self.compare_packs()
                elif choice == "4":
                    self.settings_menu()
                elif choice == "5":
                    self.other_menu()
                elif choice == "0":
                    self.save_settings(silent=True)
                    return 0
            except KeyboardInterrupt:
                print()
                self.pause("Cancelled.")
            except Exception as exc:
                self.error(str(exc))
                if self.yes_no_key("Show traceback?", False):
                    traceback.print_exc()
                self.pause()

    def print_main_menu(self) -> None:
        print()
        print(self.color("Menu actions use one key. Path settings use system pickers.", "bright_yellow"))
        print()
        for number, title, description, tag in MAIN_MENU_ITEMS:
            print_menu_item(number, title, description, tag)
        print(self.color("─" * 72, "bright_blue"))

    def other_menu(self) -> None:
        while True:
            self.clear()
            self.header("Other tools")
            print(self.color("Secondary tools. Main workflow stays pack-based.", "gray"))
            print()
            for number, title, description, tag in OTHER_MENU_ITEMS:
                print_menu_item(number, title, description, tag)
            choice = self.menu_choice("Select", {item[0] for item in OTHER_MENU_ITEMS})
            try:
                if choice == "1":
                    self.run_compare()
                elif choice == "2":
                    self.compare_json()
                elif choice == "3":
                    self.profile_stonebranch()
                elif choice == "4":
                    self.profile_jil()
                elif choice == "5":
                    self.show_last_files()
                elif choice == "0":
                    return
            except Exception as exc:
                self.error(str(exc))
                self.pause()

    def settings_menu(self) -> None:
        while True:
            self.clear()
            self.header("Settings")
            self.print_settings_compact()
            print()
            for number, title, description in SETTINGS_MENU_ITEMS:
                print(f" {self.color(number.rjust(2), 'bright_yellow', 'bold')}) {self.color(title, 'bright_yellow', 'bold')}")
                print(f"     {self.color(description, 'gray')}")
                print()
            choice = self.menu_choice("Select", {item[0] for item in SETTINGS_MENU_ITEMS})

            if choice == "1":
                self.clear()
                self.header("Current settings")
                self.print_settings_detailed()
                self.pause()
            elif choice == "2":
                self.configure_source_paths()
            elif choice == "3":
                self.configure_pack_paths()
            elif choice == "4":
                self.configure_env_mapping()
            elif choice == "5":
                self.configure_parser_options()
            elif choice == "6":
                self.configure_graph_json_paths()
            elif choice == "7":
                self.validate_paths()
                self.pause()
            elif choice == "8":
                self.save_settings()
                self.pause()
            elif choice == "9":
                self.settings = self.load_settings()
                self.success("Settings loaded.")
                self.pause()
            elif choice == "R":
                if self.yes_no_key("Reset settings to defaults?", False):
                    self.settings = TuiSettings()
                    self.success("Settings reset in memory.")
                    self.pause()
            elif choice == "0":
                return

    def configure_source_paths(self) -> None:
        self.clear()
        self.header("Source repository paths")
        s = self.settings
        print(self.color("Use the system folder picker. Manual input is only fallback.", "gray"))
        print()
        s.stonebranch_path = self.pick_folder_setting("Stonebranch PROD/DEV folder", s.stonebranch_path, Path.cwd(), allow_empty=False)
        s.jil_path = self.pick_folder_setting("JIL folder", s.jil_path, Path.cwd(), allow_empty=False)
        self.success("Source paths updated.")
        self.pause()

    def configure_pack_paths(self) -> None:
        self.clear()
        self.header("Analysis pack folders")
        s = self.settings
        print(self.color("Recommended: choose one base output folder; pack paths are filled automatically.", "gray"))
        print()
        print("1) Choose base output folder and auto-fill pack paths")
        print("2) Edit pack folders individually")
        print("0) Back")
        choice = self.menu_choice("Select", {"1", "2", "0"})

        if choice == "0":
            return

        if choice == "1":
            base_dir = self.pick_folder_setting("Base output folder", s.output_path, Path.cwd(), allow_empty=False)
            if base_dir:
                s.output_path = base_dir
                s.stonebranch_pack_path = str(Path(base_dir) / "stonebranch-pack")
                s.jil_pack_path = str(Path(base_dir) / "jil-pack")
                s.compare_pack_path = str(Path(base_dir) / "compare-pack")
                self.success("Pack folders auto-filled from base output folder.")
                self.print_settings_compact()
                self.pause()
            return

        s.stonebranch_pack_path = self.pick_folder_setting("Stonebranch pack output", s.stonebranch_pack_path, Path(s.output_path), allow_empty=False)
        s.jil_pack_path = self.pick_folder_setting("JIL pack output", s.jil_pack_path, Path(s.output_path), allow_empty=False)
        s.compare_pack_path = self.pick_folder_setting("Compare pack output", s.compare_pack_path, Path(s.output_path), allow_empty=False)
        self.success("Pack output folders updated.")
        self.pause()

    def configure_env_mapping(self) -> None:
        self.clear()
        self.header("Environment and mapping")
        s = self.settings
        s.env = self.ask("Environment name", s.env or "PROD")
        s.mapping_path = self.pick_file_setting("Mapping JSON optional", s.mapping_path, Path.cwd(), allow_empty=True)
        self.success("Environment/mapping settings updated.")
        self.pause()

    def configure_parser_options(self) -> None:
        self.clear()
        self.header("Parser and output options")
        s = self.settings
        s.include_raw_values = self.yes_no_key("Include raw command/script values?", s.include_raw_values)
        s.deep_scan = self.yes_no_key("Deep scan Stonebranch strings?", s.deep_scan)
        s.env_aware = self.yes_no_key("Env-aware Stonebranch folder layout?", s.env_aware)
        self.success("Parser/output options updated.")
        self.pause()

    def configure_graph_json_paths(self) -> None:
        self.clear()
        self.header("Existing graph.json paths")
        s = self.settings
        print(self.color("Only needed for Other tools → Compare existing graph.json files.", "gray"))
        print()
        s.stonebranch_graph_json = self.pick_file_setting("Stonebranch graph.json", s.stonebranch_graph_json, Path.cwd(), allow_empty=False)
        s.jil_graph_json = self.pick_file_setting("JIL graph.json", s.jil_graph_json, Path.cwd(), allow_empty=False)
        self.success("graph.json paths updated.")
        self.pause()

    def pick_folder_setting(self, label: str, current: str, default_start: Path, allow_empty: bool = True) -> str:
        print()
        print(self.color(label, "bright_cyan", "bold"))
        if current:
            print(f"  Current: {self.color(current, 'bright_white')}")
        print("  B = open folder picker, C = keep current, M = manual input" + (", E = empty" if allow_empty else ""))
        valid = {"B", "C", "M"} | ({"E"} if allow_empty else set())
        choice = self.menu_choice("Choose", valid)

        if choice == "C":
            return current
        if choice == "E":
            return ""
        if choice == "M":
            return self.ask(label, current)

        selected = pick_directory(label, Path(current) if current else default_start)
        if selected:
            return str(selected)

        self.warn("System folder picker is unavailable. Falling back to manual input.")
        return self.ask(label, current)

    def pick_file_setting(self, label: str, current: str, default_start: Path, allow_empty: bool = False) -> str:
        print()
        print(self.color(label, "bright_cyan", "bold"))
        if current:
            print(f"  Current: {self.color(current, 'bright_white')}")
        print("  B = open file picker, C = keep current, M = manual input" + (", E = empty" if allow_empty else ""))
        valid = {"B", "C", "M"} | ({"E"} if allow_empty else set())
        choice = self.menu_choice("Choose", valid)

        if choice == "C":
            return current
        if choice == "E":
            return ""
        if choice == "M":
            return self.ask(label, current)

        selected = pick_file(label, Path(current).parent if current else default_start)
        if selected:
            return str(selected)

        self.warn("System file picker is unavailable. Falling back to manual input.")
        return self.ask(label, current)

    def validate_paths(self) -> None:
        self.clear()
        self.header("Validate paths")
        s = self.settings
        checks = [
            ("Stonebranch source", s.stonebranch_path, True),
            ("JIL source", s.jil_path, True),
            ("Stonebranch pack", s.stonebranch_pack_path, False),
            ("JIL pack", s.jil_pack_path, False),
            ("Compare pack", s.compare_pack_path, False),
            ("Stonebranch graph.json", s.stonebranch_graph_json, True),
            ("JIL graph.json", s.jil_graph_json, True),
            ("Mapping JSON", s.mapping_path, True),
        ]
        for label, value, must_exist in checks:
            self.print_path_status(label, value, must_exist)

    def build_stonebranch_pack(self) -> None:
        s = self.ensure_settings_for("build-stonebranch-pack")
        graph = StonebranchJsonParser(
            config=self.runtime_config(),
            env=s.env,
            env_aware=s.env_aware,
            deep_scan=s.deep_scan,
        ).parse(Path(s.stonebranch_path))
        out = Path(s.stonebranch_pack_path)
        create_analysis_pack(
            graph=graph,
            output_dir=out,
            pack_type="stonebranch-analysis-pack",
            source_path=Path(s.stonebranch_path),
            env=s.env,
            include_raw_values=s.include_raw_values,
            deep_scan=s.deep_scan,
            env_aware=s.env_aware,
        )
        self.last_summary = {"nodes": len(graph.nodes), "edges": len(graph.edges)}
        self.last_files = [
            out / "README.md", out / "pack-manifest.json", out / "report.md", out / "graph.json", out / "metrics.json",
            out / "indexes" / "node-index.json", out / "graphs" / "dependencies-only.mmd", out / "reports" / "top-connected.md",
        ]
        self.success(f"Stonebranch analysis pack created: {out.resolve()}")
        self.print_summary(self.last_summary)
        self.show_last_files(pause=False)
        self.pause()

    def build_jil_pack(self) -> None:
        s = self.ensure_settings_for("build-jil-pack")
        graph = AutosysJilParser(config=self.runtime_config(), env=s.env).parse(Path(s.jil_path))
        out = Path(s.jil_pack_path)
        create_analysis_pack(
            graph=graph,
            output_dir=out,
            pack_type="jil-analysis-pack",
            source_path=Path(s.jil_path),
            env=s.env,
            include_raw_values=s.include_raw_values,
        )
        self.last_summary = {"nodes": len(graph.nodes), "edges": len(graph.edges)}
        self.last_files = [
            out / "README.md", out / "pack-manifest.json", out / "report.md", out / "graph.json", out / "metrics.json",
            out / "indexes" / "node-index.json", out / "graphs" / "dependencies-only.mmd", out / "reports" / "top-connected.md",
        ]
        self.success(f"JIL analysis pack created: {out.resolve()}")
        self.print_summary(self.last_summary)
        self.show_last_files(pause=False)
        self.pause()

    def compare_packs(self) -> None:
        s = self.ensure_settings_for("compare-packs")
        out = Path(s.compare_pack_path)
        compare_analysis_packs(
            stonebranch_pack=Path(s.stonebranch_pack_path),
            jil_pack=Path(s.jil_pack_path),
            output_dir=out,
            config=self.config,
            mapping_path=optional_path(s.mapping_path),
        )
        metrics_path = out / "compare" / "metrics.json"
        self.last_summary = json.loads(metrics_path.read_text(encoding="utf-8")) if metrics_path.exists() else {}
        self.last_files = [
            out / "compare-pack-manifest.json", out / "compare" / "report.md", out / "compare" / "comparison.json",
            out / "compare" / "metrics.json", out / "compare" / "critical-diff.json", out / "compare" / "remediation-plan.md",
        ]
        self.success(f"Comparison analysis pack created: {out.resolve()}")
        self.print_compare_summary(self.last_summary)
        self.show_last_files(pause=False)
        self.pause()

    def run_compare(self) -> None:
        s = self.ensure_settings_for("direct-compare")
        output = Path(s.output_path)
        config = self.runtime_config()
        mapping = MappingConfig.from_file(optional_path(s.mapping_path), config)
        sb_graph = StonebranchJsonParser(config, env=s.env, env_aware=s.env_aware, deep_scan=s.deep_scan).parse(Path(s.stonebranch_path))
        jil_graph = AutosysJilParser(config, env=s.env).parse(Path(s.jil_path))
        export_graph_bundle(sb_graph, output / "stonebranch")
        export_graph_bundle(jil_graph, output / "jil")
        comparison = compare_graphs(sb_graph, jil_graph, mapping, config)
        export_comparison(comparison, output, sb_graph, jil_graph)
        self.last_summary = comparison.summary
        self.last_files = [output / "compare" / "report.md", output / "compare" / "comparison.json", output / "compare" / "metrics.json"]
        self.success("Direct compare completed.")
        self.print_compare_summary(comparison.summary)
        self.show_last_files(pause=False)
        self.pause()

    def compare_json(self) -> None:
        s = self.ensure_settings_for("compare-json")
        output = Path(s.output_path)
        config = self.runtime_config()
        mapping = MappingConfig.from_file(optional_path(s.mapping_path), config)
        sb_graph = load_graph_json(Path(s.stonebranch_graph_json))
        jil_graph = load_graph_json(Path(s.jil_graph_json))
        comparison = compare_graphs(sb_graph, jil_graph, mapping, config)
        export_comparison(comparison, output, sb_graph, jil_graph)
        self.last_summary = comparison.summary
        self.last_files = [output / "compare" / "report.md", output / "compare" / "comparison.json", output / "compare" / "metrics.json"]
        self.success("Compare existing graph.json completed.")
        self.print_compare_summary(comparison.summary)
        self.show_last_files(pause=False)
        self.pause()

    def profile_stonebranch(self) -> None:
        s = self.ensure_settings_for("profile-stonebranch")
        output = Path(s.output_path) / "profile-stonebranch"
        profile_stonebranch(Path(s.stonebranch_path), output, self.runtime_config())
        self.last_summary = {"profile": "stonebranch"}
        self.last_files = [output / "schema-profile.md"]
        self.success("Stonebranch schema profile completed.")
        self.show_last_files(pause=False)
        self.pause()

    def profile_jil(self) -> None:
        s = self.ensure_settings_for("profile-jil")
        output = Path(s.output_path) / "profile-jil"
        profile_jil(Path(s.jil_path), output)
        self.last_summary = {"profile": "jil"}
        self.last_files = [output / "jil-profile.md"]
        self.success("JIL schema profile completed.")
        self.show_last_files(pause=False)
        self.pause()

    def ensure_settings_for(self, mode: str) -> TuiSettings:
        s = self.settings
        missing: list[str] = []

        if mode in {"build-stonebranch-pack", "direct-compare", "profile-stonebranch"} and not path_exists(s.stonebranch_path):
            missing.append("Stonebranch source path")
        if mode in {"build-jil-pack", "direct-compare", "profile-jil"} and not path_exists(s.jil_path):
            missing.append("JIL source path")
        if mode == "compare-packs":
            if not (path_exists(s.stonebranch_pack_path) and (Path(s.stonebranch_pack_path) / "graph.json").exists()):
                missing.append("Stonebranch analysis pack")
            if not (path_exists(s.jil_pack_path) and (Path(s.jil_pack_path) / "graph.json").exists()):
                missing.append("JIL analysis pack")
        if mode == "compare-json":
            if not path_exists(s.stonebranch_graph_json):
                missing.append("Stonebranch graph.json")
            if not path_exists(s.jil_graph_json):
                missing.append("JIL graph.json")

        if missing:
            self.warn("Missing required settings: " + ", ".join(missing))
            self.pause("Open Settings to fix these values. Press Enter...")
            self.settings_menu()

        return self.settings

    def runtime_config(self) -> AnalyzerConfig:
        return self.config.with_runtime_flags(include_raw_values=self.settings.include_raw_values)

    def print_settings_compact(self) -> None:
        s = self.settings
        print(self.color("Current settings", "bright_cyan", "bold"))
        print(f"  {self.color('Env:', 'gray')} {self.color(s.env, 'bright_white')}  "
              f"{self.color('Raw:', 'gray')} {self.flag_text(s.include_raw_values)}  "
              f"{self.color('Deep:', 'gray')} {self.flag_text(s.deep_scan)}  "
              f"{self.color('Env-aware:', 'gray')} {self.flag_text(s.env_aware)}")
        print(f"  {self.color('SB pack:', 'gray')} {self.color(s.stonebranch_pack_path, 'bright_white')}")
        print(f"  {self.color('JIL pack:', 'gray')} {self.color(s.jil_pack_path, 'bright_white')}")
        print(f"  {self.color('Compare pack:', 'gray')} {self.color(s.compare_pack_path, 'bright_white')}")

    def print_settings_detailed(self) -> None:
        s = self.settings
        rows = [
            ("Stonebranch source", s.stonebranch_path, True),
            ("JIL source", s.jil_path, True),
            ("Stonebranch pack", s.stonebranch_pack_path, False),
            ("JIL pack", s.jil_pack_path, False),
            ("Compare pack", s.compare_pack_path, False),
            ("Stonebranch graph.json", s.stonebranch_graph_json, True),
            ("JIL graph.json", s.jil_graph_json, True),
            ("Output folder", s.output_path, False),
            ("Mapping JSON", s.mapping_path, True),
        ]
        for label, value, must_exist in rows:
            self.print_path_status(label, value, must_exist)
        print()
        print(f"  {self.color('Environment:', 'gray')} {self.color(s.env, 'bright_white')}")
        print(f"  {self.color('Include raw values:', 'gray')} {self.flag_text(s.include_raw_values)}")
        print(f"  {self.color('Deep scan:', 'gray')} {self.flag_text(s.deep_scan)}")
        print(f"  {self.color('Env-aware Stonebranch:', 'gray')} {self.flag_text(s.env_aware)}")

    def print_path_status(self, label: str, value: str, must_exist_when_set: bool) -> None:
        if not value:
            print(f"  {self.color(label + ':', 'gray'):<28} {self.color('-', 'gray')}")
            return
        exists = Path(value).exists()
        status = self.color("OK", "bright_green", "bold") if exists else self.color("missing" if must_exist_when_set else "will create", "bright_red" if must_exist_when_set else "bright_yellow", "bold")
        print(f"  {self.color(label + ':', 'gray'):<28} {self.color(value, 'bright_white')} [{status}]")

    def print_summary(self, summary: dict[str, Any]) -> None:
        print()
        print(self.color("Summary", "bright_cyan", "bold"))
        for key, value in summary.items():
            print(f"  {key}: {value}")

    def print_compare_summary(self, summary: dict[str, Any]) -> None:
        print()
        print(self.color("Summary", "bright_cyan", "bold"))
        keys = ["migration_readiness_score", "readiness_grade", "matched_nodes", "matched_edges", "node_match_rate_percent", "edge_match_rate_percent", "critical_dependency_loss_count"]
        for key in keys:
            if key in summary:
                print(f"  {key}: {summary[key]}")

    def show_last_files(self, pause: bool = True) -> None:
        print()
        print(self.color("Output files", "bright_cyan", "bold"))
        if not self.last_files:
            print("  No output files yet.")
        for path in self.last_files:
            marker = self.color("OK", "bright_green", "bold") if path.exists() else self.color("missing", "bright_red", "bold")
            print(f"  [{marker}] {self.color(str(path), 'bright_white' if path.exists() else 'gray')}")
        if pause:
            self.pause()

    def menu_choice(self, label: str, valid: set[str]) -> str:
        valid_upper = {item.upper() for item in valid}
        while True:
            print(f"{self.color(label + ': ', 'bright_white', 'bold')}", end="", flush=True)
            key = get_key().upper()
            if key in valid_upper:
                print(key)
                return key
            print(self.color(f"\nInvalid key: {key or '<empty>'}", "bright_red"))

    def yes_no_key(self, label: str, current: bool) -> bool:
        default = "Y" if current else "N"
        print(f"{label} [{default}]  Y/N: ", end="", flush=True)
        while True:
            key = get_key().upper()
            if key in {"Y", "Н", "Д"}:
                print("Y")
                return True
            if key in {"N", "Т"}:
                print("N")
                return False
            if key in {"\r", "\n", ""}:
                print(default)
                return current

    def ask(self, label: str, current: str = "") -> str:
        suffix = f" [{current}]" if current else ""
        value = input(f"{label}{suffix}: ").strip()
        return value or current

    def flag_text(self, enabled: bool) -> str:
        return self.color("yes", "bright_green", "bold") if enabled else self.color("no", "gray")

    def load_settings(self) -> TuiSettings:
        if SETTINGS_FILE.exists():
            try:
                data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
                allowed_keys = set(asdict(TuiSettings()).keys())
                return TuiSettings(**{key: value for key, value in data.items() if key in allowed_keys})
            except Exception:
                return TuiSettings()
        return TuiSettings()

    def save_settings(self, silent: bool = False) -> None:
        SETTINGS_FILE.write_text(json.dumps(asdict(self.settings), indent=2, ensure_ascii=False), encoding="utf-8")
        if not silent:
            self.success(f"Settings saved to {SETTINGS_FILE}")

    def header(self, title: str = "Stonebranch Dependency Tool") -> None:
        print(self.color("╔" + "═" * 70 + "╗", "bright_blue"))
        line = f" {title} · Terminal UI · v0.5.4"
        print(self.color("║" + line.ljust(70) + "║", "bright_green", "bold"))
        print(self.color("╚" + "═" * 70 + "╝", "bright_blue"))

    def clear(self) -> None:
        if os.environ.get("TERM") and sys.stdout.isatty():
            os.system("cls" if os.name == "nt" else "clear")

    def pause(self, message: str = "Press Enter to continue...") -> None:
        input(f"\n{message}")

    def status(self, message: str) -> None:
        print(self.color(f"▶ {message}", "bright_cyan", "bold"))

    def success(self, message: str) -> None:
        print(self.color(f"✓ {message}", "bright_green", "bold"))

    def warn(self, message: str) -> None:
        print(self.color(f"⚠ {message}", "bright_yellow", "bold"))

    def error(self, message: str) -> None:
        print(self.color(f"✗ {message}", "bright_red", "bold"))

    def color(self, text: str, *styles: str) -> str:
        return color_text(text, *styles)


def optional_path(value: str) -> Path | None:
    if not value:
        return None
    path = Path(value)
    return path if path.exists() else None


def path_exists(value: str) -> bool:
    return bool(value) and Path(value).exists()


def run_tui() -> int:
    enable_windows_ansi()
    return TerminalUi().run()


if __name__ == "__main__":
    raise SystemExit(run_tui())
